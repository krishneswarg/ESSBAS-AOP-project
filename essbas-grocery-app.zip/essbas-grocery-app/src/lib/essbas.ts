export type Product = {
  id: string;
  name: string;
  category: string;
  quantity: string;
  price: number;
  essential: boolean;
  color: string;
};

export const PRODUCTS: Product[] = [
  { id: "rice", name: "Basmati Rice", category: "Grains", quantity: "10 kg", price: 600, essential: true, color: "#e9d7b7" },
  { id: "atta", name: "Whole Wheat Atta", category: "Grains", quantity: "10 kg", price: 450, essential: true, color: "#d8b98d" },
  { id: "dal", name: "Toor Dal", category: "Pulses", quantity: "5 kg", price: 500, essential: true, color: "#e8ab31" },
  { id: "oil", name: "Cooking Oil", category: "Pantry", quantity: "5 L", price: 750, essential: true, color: "#e8b928" },
  { id: "sugar", name: "Sugar", category: "Pantry", quantity: "2 kg", price: 150, essential: true, color: "#e6dfcf" },
  { id: "salt", name: "Iodised Salt", category: "Pantry", quantity: "2 kg", price: 50, essential: true, color: "#dfe8dc" },
  { id: "masala", name: "Spices & Masalas", category: "Spices", quantity: "Monthly set", price: 920, essential: true, color: "#c98242" },
  { id: "tomato", name: "Tomatoes", category: "Fruits & Vegetables", quantity: "1 kg", price: 40, essential: false, color: "#d75e44" },
  { id: "onion", name: "Red Onions", category: "Fruits & Vegetables", quantity: "1 kg", price: 35, essential: false, color: "#9b5260" },
  { id: "potato", name: "Potatoes", category: "Fruits & Vegetables", quantity: "2 kg", price: 30, essential: false, color: "#c99850" },
  { id: "banana", name: "Bananas", category: "Fruits & Vegetables", quantity: "1 dozen", price: 60, essential: false, color: "#e8c843" },
  { id: "biscuits", name: "Jeera Biscuits", category: "Snacks", quantity: "2 packs", price: 50, essential: false, color: "#b5783e" },
  { id: "tea", name: "Assam Tea", category: "Beverages", quantity: "250 g", price: 120, essential: false, color: "#55784f" },
];

export const STORAGE_KEY = "essbas-household-planner-v1";

export type Household = {
  name: string;
  familySize: number;
  phone: string;
  address: string;
};

export type OrderLine = {
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
};

export type SavedOrder = {
  id: string;
  createdAt: string;
  total: number;
  itemCount: number;
  address: string;
  items: OrderLine[];
  status: "Demo order";
};

export type AppData = {
  budget: number;
  household: Household;
  quantities: Record<string, number>;
  orders: SavedOrder[];
};

export type BasketLine = {
  product: Product;
  quantity: number;
  lineTotal: number;
};

export type BasketTotals = {
  essentials: number;
  extras: number;
  total: number;
  itemCount: number;
};

export const money = (amount: number) =>
  `₹${Math.round(amount).toLocaleString("en-IN")}`;

export function createInitialData(): AppData {
  return {
    budget: 5000,
    household: {
      name: "Priya Sharma",
      familySize: 4,
      phone: "",
      address: "12, Lake View Road, Indiranagar, Bengaluru, Karnataka 560038",
    },
    quantities: Object.fromEntries(
      PRODUCTS.filter((product) => product.essential).map((product) => [product.id, 1]),
    ),
    orders: [],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isSavedOrder(value: unknown): value is SavedOrder {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === "string" &&
    typeof value.createdAt === "string" &&
    typeof value.total === "number" &&
    typeof value.itemCount === "number" &&
    typeof value.address === "string" &&
    Array.isArray(value.items) &&
    value.status === "Demo order"
  );
}

export function readStoredData(): { data: AppData; warning: string | null } {
  if (typeof window === "undefined") {
    return { data: createInitialData(), warning: null };
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return { data: createInitialData(), warning: null };

    const stored: unknown = JSON.parse(raw);
    if (!isRecord(stored) || stored.version !== 1 || !isRecord(stored.data)) {
      throw new Error("Unsupported saved data");
    }

    const data = stored.data;
    const household = data.household;
    const quantities = data.quantities;
    const orders = data.orders;
    if (
      typeof data.budget !== "number" ||
      !Number.isFinite(data.budget) ||
      data.budget < 1 ||
      !isRecord(household) ||
      typeof household.name !== "string" ||
      typeof household.familySize !== "number" ||
      typeof household.phone !== "string" ||
      typeof household.address !== "string" ||
      !isRecord(quantities) ||
      !Array.isArray(orders) ||
      !orders.every(isSavedOrder)
    ) {
      throw new Error("Saved data is incomplete");
    }

    const safeQuantities: Record<string, number> = {};
    for (const product of PRODUCTS) {
      const quantity = quantities[product.id];
      safeQuantities[product.id] =
        typeof quantity === "number" && Number.isFinite(quantity)
          ? Math.max(0, Math.floor(quantity))
          : 0;
    }

    return {
      data: {
        budget: data.budget,
        household: {
          name: household.name,
          familySize: Math.max(1, Math.min(20, Math.floor(household.familySize))),
          phone: household.phone,
          address: household.address,
        },
        quantities: safeQuantities,
        orders,
      },
      warning: null,
    };
  } catch {
    return {
      data: createInitialData(),
      warning: "Saved data could not be read. Your starter plan is open; save it from Profile to replace the damaged browser copy.",
    };
  }
}

export function getBasket(data: AppData): BasketLine[] {
  return PRODUCTS.flatMap((product) => {
    const quantity = Math.max(0, data.quantities[product.id] ?? 0);
    return quantity > 0
      ? [{ product, quantity, lineTotal: product.price * quantity }]
      : [];
  });
}

export function getBasketTotals(data: AppData): BasketTotals {
  const lines = getBasket(data);
  const essentials = lines
    .filter((line) => line.product.essential)
    .reduce((sum, line) => sum + line.lineTotal, 0);
  const total = lines.reduce((sum, line) => sum + line.lineTotal, 0);
  return {
    essentials,
    extras: total - essentials,
    total,
    itemCount: lines.reduce((sum, line) => sum + line.quantity, 0),
  };
}
