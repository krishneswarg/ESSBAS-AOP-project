import { createContext, useContext, useState, type FormEvent, type ReactNode } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Check,
  CheckCircle2,
  ChevronRight,
  CircleHelp,
  Clock3,
  Coffee,
  Home,
  Info,
  Leaf,
  MapPin,
  Minus,
  Package,
  Plus,
  Search,
  ShoppingBasket,
  ShoppingCart,
  Sparkles,
  Sprout,
  UserRound,
  Wallet,
  Wheat,
  X,
} from "lucide-react";
import { Link, Route, Router as WouterRouter, Switch, useLocation } from "wouter";
import {
  createInitialData,
  getBasket,
  getBasketTotals,
  money,
  PRODUCTS,
  readStoredData,
  STORAGE_KEY,
  type AppData,
  type Product,
  type SavedOrder,
} from "./lib/essbas";
import "./app.css";

type StoreContextValue = {
  data: AppData;
  save: (next: AppData) => void;
  storageMessage: string | null;
  retrySave: () => void;
  openBudget: () => void;
  budgetOpen: boolean;
  closeBudget: () => void;
};

const StoreContext = createContext<StoreContextValue | null>(null);

function useStore() {
  const context = useContext(StoreContext);
  if (!context) throw new Error("ESSBAS screens must be rendered inside StoreContext.");
  return context;
}

const navigation = [
  { href: "/", label: "Home", icon: Home },
  { href: "/essentials", label: "Essentials", icon: Sprout },
  { href: "/items", label: "Add items", icon: Plus },
  { href: "/cart", label: "Your cart", icon: ShoppingCart },
  { href: "/history", label: "History", icon: Clock3 },
] as const;

const mobileNavigation = [
  navigation[0],
  navigation[1],
  navigation[2],
  navigation[3],
  { href: "/profile", label: "Profile", icon: UserRound },
] as const;

const routeLabels: Record<string, string> = {
  "/": "Home",
  "/essentials": "Essentials",
  "/items": "Add items",
  "/cart": "Your cart",
  "/checkout": "Checkout",
  "/history": "History",
  "/profile": "Profile",
};

function App() {
  const [initial] = useState(() => readStoredData());
  const [data, setData] = useState<AppData>(initial.data);
  const [storageMessage, setStorageMessage] = useState<string | null>(initial.warning);
  const [budgetOpen, setBudgetOpen] = useState(false);

  const save = (next: AppData) => {
    setData(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify({ version: 1, data: next }));
      setStorageMessage(null);
    } catch {
      setStorageMessage("Changes are visible in this session, but this browser could not save them.");
    }
  };

  const value: StoreContextValue = {
    data,
    save,
    storageMessage,
    retrySave: () => save(data),
    openBudget: () => setBudgetOpen(true),
    budgetOpen,
    closeBudget: () => setBudgetOpen(false),
  };

  return (
    <StoreContext.Provider value={value}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AppShell>
          <Switch>
            <Route path="/" component={DashboardPage} />
            <Route path="/essentials" component={EssentialsPage} />
            <Route path="/items" component={ItemsPage} />
            <Route path="/cart" component={CartPage} />
            <Route path="/checkout" component={CheckoutPage} />
            <Route path="/history" component={HistoryPage} />
            <Route path="/profile" component={ProfilePage} />
            <Route component={NotFoundPage} />
          </Switch>
        </AppShell>
      </WouterRouter>
    </StoreContext.Provider>
  );
}

function BrandMark() {
  return (
    <Link className="brand" href="/" aria-label="ESSBAS home" data-testid="brand-home">
      <span className="brand-symbol" aria-hidden="true">
        <ShoppingBasket size={24} strokeWidth={2.5} />
        <Leaf className="brand-leaf" size={11} />
      </span>
      <span className="brand-word">ESS<span>BAS</span></span>
    </Link>
  );
}

function AppShell({ children }: { children: ReactNode }) {
  const [path] = useLocation();
  const { data, storageMessage, retrySave, openBudget, budgetOpen, closeBudget } = useStore();
  const totals = getBasketTotals(data);
  const firstName = data.household.name.trim().split(/\s+/)[0] || "there";

  return (
    <div className="app-frame">
      <aside className="sidebar">
        <BrandMark />
        <div className="brand-tagline">ESSENTIALS FIRST · CHOICES BEYOND</div>

        <Link className="household-card" href="/profile" data-testid="sidebar-profile">
          <span className="avatar">{firstName.charAt(0).toUpperCase()}</span>
          <span className="household-card-copy">
            <strong>{data.household.name || "Your household"}</strong>
            <small>Family of {data.household.familySize} · Monthly plan</small>
          </span>
        </Link>

        <div className="nav-label">YOUR HOUSEHOLD</div>
        <nav className="side-nav" aria-label="Household navigation">
          {navigation.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={`side-nav-link ${path === href ? "active" : ""}`}
              aria-current={path === href ? "page" : undefined}
              data-testid={`nav-${label.toLowerCase().replaceAll(" ", "-")}`}
            >
              <Icon size={18} strokeWidth={1.9} />
              <span>{label}</span>
              {href === "/cart" && totals.itemCount > 0 && <small className="nav-count">{totals.itemCount}</small>}
            </Link>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <section className="plan-note">
            <span className="overline">YOUR MONTHLY PLAN</span>
            <strong>{money(data.budget)} for {data.household.familySize} people</strong>
            <button type="button" className="text-link" onClick={openBudget} data-testid="sidebar-adjust-budget">
              Adjust your budget <ArrowRight size={13} />
            </button>
          </section>
          <div className="nav-label">A GOOD PLAN STARTS HERE</div>
          <Link className="side-nav-link" href="/essentials" data-testid="planning-guide">
            <CircleHelp size={18} strokeWidth={1.9} />
            <span>Planning guide</span>
          </Link>
          <p className="local-note">Your plan is saved on this device.</p>
        </div>
      </aside>

      <main className="main-column">
        <header className="topbar">
          <BrandMark />
          <div className="breadcrumb"><strong>ESSBAS</strong><span>/</span>{routeLabels[path] ?? "Page"}</div>
          <div className="topbar-actions">
            <span className="topbar-note">Your home, thoughtfully stocked</span>
            <Link className="icon-button" href="/history" aria-label="Order history" data-testid="topbar-history">
              <Bell size={17} />
            </Link>
            <Link className="avatar avatar-button" href="/profile" aria-label="Household profile" data-testid="topbar-profile">
              {firstName.charAt(0).toUpperCase()}
            </Link>
          </div>
        </header>

        {storageMessage && (
          <div className="storage-alert" role="status" data-testid="storage-message">
            <Info size={17} />
            <span>{storageMessage}</span>
            <button type="button" onClick={retrySave} data-testid="retry-storage">Try saving</button>
          </div>
        )}

        <div className="page-content">{children}</div>
      </main>

      <nav className="mobile-nav" aria-label="Mobile navigation">
        {mobileNavigation.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`mobile-nav-link ${path === href ? "active" : ""}`}
            aria-current={path === href ? "page" : undefined}
            data-testid={`mobile-nav-${label.toLowerCase().replaceAll(" ", "-")}`}
          >
            <span className="mobile-icon">
              <Icon size={19} strokeWidth={1.9} />
              {href === "/cart" && totals.itemCount > 0 && <i className="mobile-count">{totals.itemCount}</i>}
            </span>
            <span>{label}</span>
          </Link>
        ))}
      </nav>

      {budgetOpen && <BudgetDialog onClose={closeBudget} />}
    </div>
  );
}

function PageHeader({
  eyebrow,
  title,
  subtitle,
  action,
}: {
  eyebrow: string;
  title: string;
  subtitle: string;
  action?: ReactNode;
}) {
  return (
    <div className="page-header">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1>{title}</h1>
        <p>{subtitle}</p>
      </div>
      {action && <div className="page-header-action">{action}</div>}
    </div>
  );
}

function DashboardPage() {
  const { data, openBudget } = useStore();
  const totals = getBasketTotals(data);
  const firstName = data.household.name.trim().split(/\s+/)[0] || "there";
  const budgetUsed = Math.min(100, (totals.total / data.budget) * 100);

  return (
    <>
      <PageHeader
        eyebrow="YOUR MONTHLY GROCERY PLAN"
        title={`Good morning, ${firstName}`}
        subtitle="Let’s make this month’s groceries count."
        action={<button className="button button-outline" type="button" onClick={openBudget} data-testid="dashboard-set-budget"><Wallet size={15} /> Set budget</button>}
      />

      <div className="dashboard-grid">
        <section className="budget-card" aria-label="Monthly grocery budget">
          <div className="budget-card-head">
            <div><span>Monthly grocery budget</span><strong data-testid="monthly-budget">{money(data.budget)}</strong></div>
            <button type="button" className="budget-edit" onClick={openBudget} data-testid="budget-edit">Set / Edit</button>
          </div>
          <div className="budget-track" role="progressbar" aria-label="Budget used" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(budgetUsed)}>
            <span style={{ width: `${budgetUsed}%` }} />
          </div>
          <div className="budget-metrics"><span>Basket {money(totals.total)}</span><span>{money(Math.max(0, data.budget - totals.total))} left to plan</span></div>
        </section>

        <section className="panel essentials-covered">
          <div className="panel-heading"><h2>Essentials are covered</h2><span className="check-badge"><Check size={16} /></span></div>
          <strong className="essentials-amount" data-testid="essentials-total">{money(totals.essentials)}</strong>
          <p>of {money(data.budget)} monthly budget · family of {data.household.familySize}</p>
          <div className="progress-track"><span style={{ width: `${Math.min(100, (totals.essentials / data.budget) * 100)}%` }} /></div>
          <Link className="inline-link" href="/essentials">Review essentials <ChevronRight size={14} /></Link>
        </section>
      </div>

      <div className="dashboard-grid lower-grid">
        <section className="panel quick-panel">
          <div className="panel-heading"><h2>A good place to start</h2><span className="subtle">Your plan, your pace</span></div>
          <div className="shortcuts">
            <QuickLink href="/essentials" label="Essentials" icon={<Sprout />} />
            <QuickLink href="/items" label="Add items" icon={<Plus />} />
            <QuickLink href="/cart" label="Your basket" icon={<ShoppingCart />} />
            <QuickLink href="/history" label="Past orders" icon={<Clock3 />} />
          </div>
        </section>
        <section className="tip-card">
          <Sparkles size={18} />
          <div><h2>Essentials first. Choices beyond.</h2><p>Your staples come to {money(totals.essentials)}. That leaves {money(Math.max(0, data.budget - totals.essentials))} for the extras your family enjoys.</p></div>
        </section>
      </div>

      <div className="dashboard-grid lower-grid summary-grid">
        <section className="panel month-summary">
          <div className="panel-heading"><h2>This month at a glance</h2><span className="subtle">Family of {data.household.familySize}</span></div>
          <SummaryLine label="Monthly grocery budget" amount={data.budget} />
          <SummaryLine label="Essential groceries" amount={totals.essentials} />
          <SummaryLine label="Optional items in basket" amount={totals.extras} />
        </section>
        <section className="remaining-card">
          <div><span>Room for thoughtful choices</span><strong data-testid="remaining-budget">{money(Math.max(0, data.budget - totals.total))}</strong></div>
          <span className="remaining-icon"><Leaf size={19} /></span>
        </section>
      </div>
    </>
  );
}

function QuickLink({ href, label, icon }: { href: string; label: string; icon: ReactNode }) {
  return <Link href={href} className="shortcut" data-testid={`shortcut-${label.toLowerCase().replaceAll(" ", "-")}`}><span>{icon}</span>{label}</Link>;
}

function SummaryLine({ label, amount }: { label: string; amount: number }) {
  return <div className="summary-line"><span>{label}</span><strong>{money(amount)}</strong></div>;
}

function ProductIcon({ product, small = false }: { product: Product; small?: boolean }) {
  const icon = product.category === "Fruits & Vegetables"
    ? <Sprout size={small ? 21 : 25} />
    : product.category === "Beverages"
      ? <Coffee size={small ? 21 : 25} />
      : product.essential
        ? <Wheat size={small ? 21 : 25} />
        : <Package size={small ? 21 : 25} />;
  return <span className={`product-art ${small ? "small" : ""}`} style={{ backgroundColor: `${product.color}39`, color: product.color }}>
    <span style={{ color: product.color }}>{icon}</span>
  </span>;
}

function QuantityControl({ productId, quantity, onChange }: { productId: string; quantity: number; onChange: (amount: number) => void }) {
  return (
    <div className="quantity-control" aria-label={`Quantity: ${quantity}`}>
      <button type="button" aria-label="Decrease quantity" onClick={() => onChange(-1)} data-testid={`quantity-decrease-${productId}`}><Minus size={13} /></button>
      <span data-testid={`quantity-${productId}`}>{quantity}</span>
      <button type="button" aria-label="Increase quantity" onClick={() => onChange(1)} data-testid={`quantity-increase-${productId}`}><Plus size={13} /></button>
    </div>
  );
}

function ProductRow({ product }: { product: Product }) {
  const { data, save } = useStore();
  const quantity = data.quantities[product.id] ?? 0;
  const update = (amount: number) => save({
    ...data,
    quantities: { ...data.quantities, [product.id]: Math.max(0, quantity + amount) },
  });

  return (
    <article className="product-row" data-testid={`product-${product.id}`}>
      <ProductIcon product={product} />
      <div className="product-info"><h3>{product.name}</h3><p>{product.quantity} · {product.category}{product.essential ? " · Monthly essential" : ""}</p></div>
      <strong className="product-price">{money(product.price)}</strong>
      <div className="product-action">
        {quantity > 0
          ? <QuantityControl productId={product.id} quantity={quantity} onChange={update} />
          : <button type="button" className="add-button" onClick={() => update(1)} data-testid={`add-${product.id}`}><Plus size={13} /> Add</button>}
      </div>
    </article>
  );
}

function EssentialsPage() {
  const { data, openBudget } = useStore();
  const totals = getBasketTotals(data);
  const essentials = PRODUCTS.filter((product) => product.essential);

  return (
    <>
      <PageHeader
        eyebrow="ESSENTIALS FIRST, ALWAYS"
        title="Your essentials"
        subtitle="The everyday staples your family can count on."
        action={<Link className="button button-primary" href="/cart"><ShoppingCart size={15} /> Basket · {totals.itemCount}</Link>}
      />
      <div className="catalog-layout">
        <div className="product-list">{essentials.map((product) => <ProductRow key={product.id} product={product} />)}</div>
        <aside className="panel side-summary">
          <div className="eyebrow">FIXED FOR YOUR HOUSEHOLD</div>
          <h2>Essential basket</h2>
          <strong className="side-total" data-testid="essentials-page-total">{money(totals.essentials)}</strong>
          <p>Estimated monthly essentials</p>
          <div className="progress-track"><span style={{ width: `${Math.min(100, (totals.essentials / data.budget) * 100)}%` }} /></div>
          <SummaryLine label="Monthly plan" amount={data.budget} />
          <SummaryLine label="Remaining for extras" amount={Math.max(0, data.budget - totals.essentials)} />
          <Link className="button button-primary full-button" href="/items">Continue to add items <ArrowRight size={15} /></Link>
          <button type="button" className="text-link summary-edit" onClick={openBudget}>Adjust this budget <ChevronRight size={13} /></button>
          <p className="quiet-note">Quantities are sized for a family of {data.household.familySize}. Adjust them to fit your home.</p>
        </aside>
      </div>
    </>
  );
}

function ItemsPage() {
  const { data } = useStore();
  const totals = getBasketTotals(data);
  const categories = ["All", ...new Set(PRODUCTS.filter((product) => !product.essential).map((product) => product.category))];
  const [category, setCategory] = useState("All");
  const [query, setQuery] = useState("");
  const extras = PRODUCTS.filter((product) => {
    if (product.essential) return false;
    const matchesCategory = category === "All" || product.category === category;
    const matchesQuery = `${product.name} ${product.category}`.toLowerCase().includes(query.toLowerCase().trim());
    return matchesCategory && matchesQuery;
  });

  return (
    <>
      <PageHeader eyebrow="MAKE THE MOST OF WHAT'S LEFT" title="A little extra" subtitle="Thoughtful additions, within what’s left." action={<Link className="button button-primary" href="/cart"><ShoppingCart size={15} /> Basket · {totals.itemCount}</Link>} />
      <div className="catalog-toolbar">
        <label className="search-box"><Search size={17} /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Find a grocery item" aria-label="Find a grocery item" data-testid="item-search" /></label>
        <div className="filter-list" aria-label="Filter by category">
          {categories.map((name) => <button key={name} type="button" className={`filter-chip ${category === name ? "active" : ""}`} onClick={() => setCategory(name)} aria-pressed={category === name} data-testid={`filter-${name.toLowerCase().replaceAll(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}`}>{name}</button>)}
        </div>
      </div>
      <div className="catalog-layout">
        <div className="product-list">
          {extras.length > 0
            ? extras.map((product) => <ProductRow key={product.id} product={product} />)
            : <div className="empty-state"><Search size={23} /><strong>No groceries found</strong><span>Try another search or category.</span><button className="button button-outline" type="button" onClick={() => { setQuery(""); setCategory("All"); }}>Clear filters</button></div>}
        </div>
        <aside className="panel side-summary">
          <div className="eyebrow">YOUR BASKET SO FAR</div>
          <h2>A little extra?</h2>
          <strong className="side-total" data-testid="items-basket-total">{money(totals.total)}</strong>
          <p>of {money(data.budget)} monthly budget</p>
          <div className="progress-track"><span style={{ width: `${Math.min(100, (totals.total / data.budget) * 100)}%` }} /></div>
          <SummaryLine label="Essentials" amount={totals.essentials} />
          <SummaryLine label="Room remaining" amount={data.budget - totals.total} />
          <Link className="button button-primary full-button" href="/cart">Review basket <ArrowRight size={15} /></Link>
          <p className="quiet-note">A thoughtful choice can be as simple as a kilo of fruit.</p>
        </aside>
      </div>
    </>
  );
}

function CartPage() {
  const { data, save, openBudget } = useStore();
  const [, navigate] = useLocation();
  const lines = getBasket(data);
  const totals = getBasketTotals(data);
  const over = totals.total > data.budget;
  const [decisionOpen, setDecisionOpen] = useState(false);

  const changeQuantity = (id: string, delta: number) => save({
    ...data,
    quantities: { ...data.quantities, [id]: Math.max(0, (data.quantities[id] ?? 0) + delta) },
  });

  const continueCheckout = () => {
    if (over) setDecisionOpen(true);
    else navigate("/checkout");
  };

  return (
    <>
      <PageHeader eyebrow="ESSENTIALS FIRST, ALWAYS" title="Your basket" subtitle="Everything in one place, with your budget in view." />
      <div className="cart-layout">
        <section className="panel cart-list" aria-label="Items in your basket">
          {lines.length > 0
            ? lines.map(({ product, quantity, lineTotal }) => (
              <article className="cart-line" key={product.id} data-testid={`cart-line-${product.id}`}>
                <ProductIcon product={product} small />
                <div className="cart-line-copy"><h2>{product.name}</h2><p>{product.quantity} · {product.essential ? "Essential" : "Optional"}</p><span>{money(product.price)} each</span></div>
                <div className="cart-line-actions"><strong>{money(lineTotal)}</strong><QuantityControl productId={product.id} quantity={quantity} onChange={(delta) => changeQuantity(product.id, delta)} /></div>
              </article>
            ))
            : <div className="empty-state"><ShoppingBasket size={25} /><strong>Your basket is waiting for something good.</strong><span>Add essentials or a few favourites to get started.</span><Link className="button button-primary" href="/essentials">Start with essentials</Link></div>}
        </section>

        <aside className="panel totals-panel">
          <h2>Your monthly plan</h2>
          <SummaryLine label="Essentials" amount={totals.essentials} />
          <SummaryLine label="Optional groceries" amount={totals.extras} />
          <div className="total-line"><span>Basket total</span><strong data-testid="cart-total">{money(totals.total)}</strong></div>
          <SummaryLine label="Monthly budget" amount={data.budget} />
          <SummaryLine label="Remaining" amount={data.budget - totals.total} />
          {over && <div className="budget-warning" role="alert"><Info size={17} /><span>Your basket is <strong>{money(totals.total - data.budget)}</strong> over this month’s plan.</span></div>}
          {decisionOpen && over && (
            <div className="decision-card" data-testid="budget-overage-options">
              <h3>Let’s make a choice together</h3>
              <p>Your basket is over budget. You can continue with this demo, review extras, or update your plan.</p>
              <button type="button" className="button button-primary full-button" onClick={() => navigate("/checkout")} data-testid="continue-over-budget">Continue anyway <ArrowRight size={15} /></button>
              <Link className="button button-outline full-button" href="/items">Review extras</Link>
              <button type="button" className="text-link decision-link" onClick={openBudget}>Increase my budget</button>
            </div>
          )}
          {!decisionOpen && (
            <button type="button" className="button button-primary full-button" onClick={continueCheckout} disabled={totals.itemCount === 0} data-testid="checkout-from-cart">
              {over ? "Make a budget choice" : "Continue to checkout"} <ArrowRight size={15} />
            </button>
          )}
          <Link className="text-link keep-shopping" href="/items">Keep adding groceries <ChevronRight size={14} /></Link>
        </aside>
      </div>
    </>
  );
}

function CheckoutPage() {
  const { data, save } = useStore();
  const [, navigate] = useLocation();
  const totals = getBasketTotals(data);
  const [error, setError] = useState("");
  const [placing, setPlacing] = useState(false);

  const updateHousehold = (field: keyof AppData["household"], value: string) => {
    save({ ...data, household: { ...data.household, [field]: value } });
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (totals.itemCount === 0) {
      setError("Add at least one grocery item before saving this demo order.");
      return;
    }
    if (!data.household.name.trim() || !data.household.address.trim()) {
      setError("Add a name and delivery address to continue.");
      return;
    }
    setError("");
    setPlacing(true);
    const lines = getBasket(data);
    const order: SavedOrder = {
      id: `ES-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
      total: totals.total,
      itemCount: totals.itemCount,
      address: data.household.address,
      items: lines.map(({ product, quantity, lineTotal }) => ({
        productId: product.id,
        name: product.name,
        quantity,
        unitPrice: product.price,
        lineTotal,
      })),
      status: "Demo order",
    };
    save({ ...data, orders: [order, ...data.orders] });
    window.setTimeout(() => navigate("/history"), 200);
  };

  return (
    <>
      <button className="back-link" type="button" onClick={() => navigate("/cart")}><ArrowLeft size={14} /> Back to basket</button>
      <PageHeader eyebrow="DEMO CHECKOUT" title="Ready to save your plan?" subtitle="Review the household details and keep a local order record." />
      <div className="checkout-steps" aria-label="Checkout progress"><span className="complete"><Check size={12} /> Basket</span><i /><span className="current">2&nbsp; Details</span><i /><span>3&nbsp; Saved</span></div>
      <div className="checkout-layout">
        <form className="panel checkout-form" onSubmit={submit} noValidate>
          <div className="panel-heading"><h2>Household details</h2><span className="subtle">Saved on this device</span></div>
          <p className="form-intro">This information stays in your browser. No retailer receives it.</p>
          <label className="field-label">Full name
            <input required value={data.household.name} onChange={(event) => updateHousehold("name", event.target.value)} autoComplete="name" data-testid="checkout-name" />
          </label>
          <label className="field-label">Delivery address
            <textarea required rows={3} value={data.household.address} onChange={(event) => updateHousehold("address", event.target.value)} autoComplete="street-address" data-testid="checkout-address" />
          </label>
          <label className="field-label">Phone number <span className="optional-label">Optional</span>
            <input type="tel" value={data.household.phone} onChange={(event) => updateHousehold("phone", event.target.value)} autoComplete="tel" data-testid="checkout-phone" />
          </label>
          <div className="payment-note"><Wallet size={17} /><div><strong>No payment is collected</strong><span>This is a local demo. No order is sent to a store and no delivery is scheduled.</span></div></div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="button button-primary full-button" type="submit" disabled={placing || totals.itemCount === 0} data-testid="place-demo-order">
            {placing ? "Saving…" : "Save demo order"} <CheckCircle2 size={16} />
          </button>
        </form>
        <aside className="panel totals-panel checkout-summary">
          <h2>Basket summary</h2>
          {getBasket(data).map(({ product, quantity, lineTotal }) => <div className="summary-line" key={product.id}><span>{product.name} × {quantity}</span><strong>{money(lineTotal)}</strong></div>)}
          <div className="total-line"><span>Demo total</span><strong data-testid="checkout-total">{money(totals.total)}</strong></div>
          <p className="quiet-note">This amount is for planning only; no payment or purchase will occur.</p>
        </aside>
      </div>
    </>
  );
}

function HistoryPage() {
  const { data } = useStore();
  const [selectedOrder, setSelectedOrder] = useState<string | null>(null);
  const selected = data.orders.find((order) => order.id === selectedOrder);

  return (
    <>
      <PageHeader eyebrow="YOUR HOUSEHOLD" title="Order history" subtitle="Demo orders saved in this browser." action={<Link className="button button-primary" href="/items"><Plus size={15} /> Plan groceries</Link>} />
      {data.orders.length === 0
        ? <div className="empty-state history-empty"><ShoppingBasket size={25} /><strong>You haven’t saved any demo orders yet.</strong><span>Your order records will stay on this device.</span><Link className="button button-primary" href="/essentials">Start with essentials <ArrowRight size={15} /></Link></div>
        : <div className="history-layout">
          <div className="history-list">
            {data.orders.map((order) => (
              <button className={`panel order-card ${selectedOrder === order.id ? "selected" : ""}`} type="button" key={order.id} onClick={() => setSelectedOrder(order.id)} data-testid={`order-${order.id}`}>
                <span className="order-icon"><ShoppingBasket size={20} /></span>
                <span className="order-copy"><strong>Monthly grocery basket</strong><small>{order.id} · {formatDate(order.createdAt)} · {order.itemCount} items</small></span>
                <span className="order-total"><strong>{money(order.total)}</strong><small>Demo order</small></span>
              </button>
            ))}
          </div>
          {selected && <OrderDetail order={selected} />}
        </div>}
    </>
  );
}

function OrderDetail({ order }: { order: SavedOrder }) {
  return (
    <section className="panel order-detail">
      <div className="panel-heading"><h2>Order details</h2><span className="status-pill">Demo only</span></div>
      <p className="order-detail-id">{order.id} · {formatDate(order.createdAt)}</p>
      {order.items.map((item) => <SummaryLine key={item.productId} label={`${item.name} × ${item.quantity}`} amount={item.lineTotal} />)}
      <div className="total-line"><span>Total</span><strong>{money(order.total)}</strong></div>
      <div className="detail-address"><MapPin size={16} /><span>{order.address}</span></div>
      <p className="quiet-note">Saved in this browser only. This is not a retailer order.</p>
    </section>
  );
}

function ProfilePage() {
  const { data, save } = useStore();
  const [draft, setDraft] = useState(data.household);
  const [budgetDraft, setBudgetDraft] = useState(String(data.budget));
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const budget = Number(budgetDraft);
    if (!draft.name.trim() || !draft.address.trim()) {
      setError("Add a household name and address.");
      return;
    }
    if (!Number.isFinite(budget) || budget < 1000) {
      setError("Set a monthly budget of at least ₹1,000.");
      return;
    }
    save({
      ...data,
      budget,
      household: {
        ...draft,
        familySize: Math.max(1, Math.min(20, Math.floor(Number(draft.familySize) || 1))),
      },
    });
    setError("");
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2200);
  };

  const reset = () => {
    if (window.confirm("Reset this browser’s ESSBAS budget, basket, household details, and demo orders? This cannot be undone.")) {
      save(createInitialData());
      setDraft(createInitialData().household);
      setBudgetDraft("5000");
    }
  };

  return (
    <>
      <PageHeader eyebrow="YOUR HOUSEHOLD" title="Household profile" subtitle="Keep your grocery plan in step with your home." />
      <div className="profile-layout">
        <form className="panel profile-form" onSubmit={submit}>
          <div className="panel-heading"><h2>Household details</h2><span className="subtle">Saved on this device</span></div>
          <label className="field-label">Household contact
            <input value={draft.name} onChange={(event) => setDraft({ ...draft, name: event.target.value })} required autoComplete="name" data-testid="profile-name" />
          </label>
          <label className="field-label">Family members
            <input type="number" min="1" max="20" value={draft.familySize} onChange={(event) => setDraft({ ...draft, familySize: Number(event.target.value) })} required data-testid="profile-family-size" />
          </label>
          <label className="field-label">Phone number <span className="optional-label">Optional</span>
            <input type="tel" value={draft.phone} onChange={(event) => setDraft({ ...draft, phone: event.target.value })} autoComplete="tel" data-testid="profile-phone" />
          </label>
          <label className="field-label">Delivery address
            <textarea rows={3} value={draft.address} onChange={(event) => setDraft({ ...draft, address: event.target.value })} required autoComplete="street-address" data-testid="profile-address" />
          </label>
          <label className="field-label">Monthly grocery budget
            <span className="money-input"><span>₹</span><input type="number" min="1000" step="100" value={budgetDraft} onChange={(event) => setBudgetDraft(event.target.value)} required data-testid="profile-budget" /></span>
          </label>
          {error && <p className="form-error" role="alert">{error}</p>}
          {saved && <p className="form-success" role="status"><Check size={15} /> Household details saved.</p>}
          <button className="button button-primary" type="submit" data-testid="save-profile">Save changes</button>
        </form>
        <aside className="panel privacy-panel">
          <span className="privacy-icon"><Info size={19} /></span>
          <h2>Your plan stays yours</h2>
          <p>Budget, basket, household details, and demo orders are stored in this browser. They do not sync to another device or an online store.</p>
          <button type="button" className="button button-danger-outline" onClick={reset} data-testid="reset-demo-data">Reset demo data</button>
        </aside>
      </div>
    </>
  );
}

function BudgetDialog({ onClose }: { onClose: () => void }) {
  const { data, save } = useStore();
  const [draft, setDraft] = useState(String(data.budget));
  const [error, setError] = useState("");
  const totals = getBasketTotals(data);

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const budget = Number(draft);
    if (!Number.isFinite(budget) || budget < 1000) {
      setError("Enter a monthly budget of at least ₹1,000.");
      return;
    }
    save({ ...data, budget });
    onClose();
  };

  return (
    <div className="dialog-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <form className="budget-dialog" role="dialog" aria-modal="true" aria-labelledby="budget-dialog-title" onSubmit={submit}>
        <button className="dialog-close" type="button" onClick={onClose} aria-label="Close budget editor" data-testid="close-budget"><X size={17} /></button>
        <span className="dialog-icon"><Wallet size={20} /></span>
        <div className="eyebrow">A PLAN THAT FITS YOUR HOME</div>
        <h2 id="budget-dialog-title">Set your monthly budget</h2>
        <p>Choose a grocery amount that feels right for your family of {data.household.familySize}.</p>
        <label className="money-input dialog-money"><span>₹</span><input autoFocus type="number" min="1000" step="100" value={draft} onChange={(event) => setDraft(event.target.value)} aria-label="Monthly grocery budget" data-testid="budget-input" /></label>
        <div className="dialog-helper">Your current basket is {money(totals.total)} per month.</div>
        {error && <p className="form-error" role="alert">{error}</p>}
        <button className="button button-primary full-button" type="submit" data-testid="save-budget">Save monthly budget <ArrowRight size={15} /></button>
      </form>
    </div>
  );
}

function NotFoundPage() {
  return <div className="empty-state"><Search size={24} /><strong>We couldn’t find that page.</strong><span>Return to your monthly grocery plan.</span><Link className="button button-primary" href="/">Go to home</Link></div>;
}

function formatDate(value: string) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Date unavailable"
    : date.toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}

export default App;
