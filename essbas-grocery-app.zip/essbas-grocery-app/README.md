# ESSBAS Grocery Budget App

Exact copy of the Replit web app (React + Vite + Tailwind). Set a monthly budget, manage staples and optional groceries, review the basket, simulate checkout, and keep order history saved in the browser.

Requires Node.js 20 or newer.

## Run on localhost

```bash
npm install
npm run dev
```

Open http://localhost:3000

To present the production version instead:

```bash
npm run build
npm run preview
```

## Upload to GitHub

```bash
git init
git add .
git commit -m "ESSBAS Grocery Budget App"
git branch -M main
git remote add origin https://github.com/<your-username>/essbas-grocery-budget-app.git
git push -u origin main
```

Create the empty repository on github.com first. `node_modules` and `dist` are already in `.gitignore`.

## Deploy on Vercel

1. Vercel > Add New > Project > import the GitHub repo.
2. Framework Preset: **Vite** (auto-detected).
3. Build command `npm run build`, output directory `dist` (the defaults).
4. Deploy. `vercel.json` already handles page refreshes on sub-routes.
